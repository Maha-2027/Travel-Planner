require('dotenv').config();
const express = require('express');
const cors = require('cors');
const session = require('express-session');
const bcrypt = require('bcryptjs');
const mysql = require('mysql2/promise');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors({ origin: true, credentials: true }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: process.env.SESSION_SECRET || 'travel-planner-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 }
}));

// ─── Database Pool ────────────────────────────────────────────────────────────
let db;
async function initDB() {
  try {
    db = await mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || 3306,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || '',
      database: process.env.DB_NAME || 'travel_planner',
      waitForConnections: true,
      connectionLimit: 10
    });
    const [rows] = await db.query('SELECT 1');
    console.log('✅ MySQL connected successfully');
    return true;
  } catch (err) {
    console.warn('⚠️  MySQL not available — running with in-memory mock data');
    console.warn('   Configure .env with your DB credentials and restart.');
    db = null;
    return false;
  }
}

// ─── In-memory Mock Data (fallback when MySQL is unavailable) ─────────────────
const mockUsers = [];
const mockPlans = [];
const mockDestinations = [
  { id:1, name:'Paris', country:'France', short_desc:'City of light, love & haute cuisine', image_url:'https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=800', avg_cost_usd:2200, best_season:'Apr–Jun, Sep–Oct', category:'city', rating:4.8 },
  { id:2, name:'Tokyo', country:'Japan', short_desc:'Where tradition meets neon-lit future', image_url:'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800', avg_cost_usd:2500, best_season:'Mar–May, Sep–Nov', category:'city', rating:4.9 },
  { id:3, name:'Bali', country:'Indonesia', short_desc:'Island of gods, temples & surf', image_url:'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=800', avg_cost_usd:1200, best_season:'Apr–Oct', category:'beach', rating:4.7 },
  { id:4, name:'New York', country:'USA', short_desc:'The city that never sleeps', image_url:'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=800', avg_cost_usd:3000, best_season:'Apr–Jun, Sep–Nov', category:'city', rating:4.7 },
  { id:5, name:'Cape Town', country:'South Africa', short_desc:'Where mountains meet the ocean', image_url:'https://images.unsplash.com/photo-1580060839134-75a5edca2e99?w=800', avg_cost_usd:1500, best_season:'Nov–Mar', category:'nature', rating:4.8 },
  { id:6, name:'Santorini', country:'Greece', short_desc:'Whitewashed cliffs & volcanic sunsets', image_url:'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800', avg_cost_usd:2800, best_season:'May–Oct', category:'beach', rating:4.9 },
  { id:7, name:'Machu Picchu', country:'Peru', short_desc:'Lost city of the Inca empire', image_url:'https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800', avg_cost_usd:1800, best_season:'May–Sep', category:'adventure', rating:4.9 },
  { id:8, name:'Maldives', country:'Maldives', short_desc:'Overwater bungalows & crystal lagoons', image_url:'https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800', avg_cost_usd:4500, best_season:'Nov–Apr', category:'beach', rating:4.9 },
  { id:9, name:'Safari Kenya', country:'Kenya', short_desc:'The great migration & big five', image_url:'https://images.unsplash.com/photo-1523805009345-7448845a9e53?w=800', avg_cost_usd:3500, best_season:'Jul–Oct', category:'adventure', rating:4.8 },
  { id:10, name:'Amsterdam', country:'Netherlands', short_desc:'Canals, cycling & golden age art', image_url:'https://images.unsplash.com/photo-1534351590666-13e3e96b5017?w=800', avg_cost_usd:1900, best_season:'Apr–Aug', category:'city', rating:4.6 }
];

// ─── Auth Middleware ──────────────────────────────────────────────────────────
function requireAuth(req, res, next) {
  if (req.session && req.session.userId) return next();
  return res.status(401).json({ error: 'Not authenticated' });
}

// ─── Auth Routes ──────────────────────────────────────────────────────────────
app.post('/api/auth/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.status(400).json({ error: 'All fields are required' });
  if (password.length < 6)
    return res.status(400).json({ error: 'Password must be at least 6 characters' });

  try {
    const hashedPassword = await bcrypt.hash(password, 12);
    if (db) {
      const [existing] = await db.query('SELECT id FROM users WHERE email = ?', [email]);
      if (existing.length) return res.status(409).json({ error: 'Email already registered' });
      const [result] = await db.query(
        'INSERT INTO users (name, email, password) VALUES (?, ?, ?)',
        [name, email, hashedPassword]
      );
      req.session.userId = result.insertId;
      req.session.userName = name;
    } else {
      if (mockUsers.find(u => u.email === email))
        return res.status(409).json({ error: 'Email already registered' });
      const id = mockUsers.length + 1;
      mockUsers.push({ id, name, email, password: hashedPassword });
      req.session.userId = id;
      req.session.userName = name;
    }
    res.json({ success: true, user: { name, email } });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password)
    return res.status(400).json({ error: 'Email and password are required' });

  try {
    let user;
    if (db) {
      const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
      user = rows[0];
    } else {
      user = mockUsers.find(u => u.email === email);
    }
    if (!user) return res.status(401).json({ error: 'Invalid email or password' });
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(401).json({ error: 'Invalid email or password' });

    req.session.userId = user.id;
    req.session.userName = user.name;
    res.json({ success: true, user: { name: user.name, email: user.email } });
  } catch (err) {
    res.status(500).json({ error: 'Login failed' });
  }
});

app.post('/api/auth/logout', (req, res) => {
  req.session.destroy();
  res.json({ success: true });
});

app.get('/api/auth/me', (req, res) => {
  if (req.session && req.session.userId) {
    res.json({ authenticated: true, name: req.session.userName, id: req.session.userId });
  } else {
    res.json({ authenticated: false });
  }
});

// ─── Destinations Routes ──────────────────────────────────────────────────────
app.get('/api/destinations', async (req, res) => {
  try {
    if (db) {
      const [rows] = await db.query('SELECT * FROM destinations ORDER BY rating DESC');
      return res.json(rows);
    }
    res.json(mockDestinations);
  } catch (err) {
    res.json(mockDestinations);
  }
});

app.get('/api/destinations/:id', async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    if (db) {
      const [rows] = await db.query('SELECT * FROM destinations WHERE id = ?', [id]);
      if (!rows.length) return res.status(404).json({ error: 'Not found' });
      return res.json(rows[0]);
    }
    const dest = mockDestinations.find(d => d.id === id);
    if (!dest) return res.status(404).json({ error: 'Not found' });
    res.json(dest);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch destination' });
  }
});

// ─── Plans Routes ─────────────────────────────────────────────────────────────
app.get('/api/plans', requireAuth, async (req, res) => {
  try {
    if (db) {
      const [rows] = await db.query(
        'SELECT tp.*, d.name as dest_name, d.image_url FROM travel_plans tp LEFT JOIN destinations d ON tp.destination_id = d.id WHERE tp.user_id = ? ORDER BY tp.created_at DESC',
        [req.session.userId]
      );
      return res.json(rows);
    }
    res.json(mockPlans.filter(p => p.user_id === req.session.userId));
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch plans' });
  }
});

app.post('/api/plans', requireAuth, async (req, res) => {
  const plan = { ...req.body, user_id: req.session.userId };
  try {
    if (db) {
      const [result] = await db.query(
        `INSERT INTO travel_plans (user_id, destination_id, destination_name, departure_city, travel_date, return_date, travelers, accommodation_type, accommodation_stars, flight_class, car_rental, car_type, food_preference, total_budget_usd, currency, notes)
         VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`,
        [plan.user_id, plan.destination_id||null, plan.destination_name, plan.departure_city, plan.travel_date, plan.return_date, plan.travelers||1, plan.accommodation_type||'hotel', plan.accommodation_stars||3, plan.flight_class||'economy', plan.car_rental||false, plan.car_type||null, plan.food_preference||'mixed', plan.total_budget_usd||null, plan.currency||'USD', plan.notes||null]
      );
      return res.json({ success: true, id: result.insertId });
    }
    const id = mockPlans.length + 1;
    mockPlans.push({ id, ...plan, created_at: new Date() });
    res.json({ success: true, id });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to save plan' });
  }
});

app.delete('/api/plans/:id', requireAuth, async (req, res) => {
  const id = parseInt(req.params.id);
  try {
    if (db) {
      await db.query('DELETE FROM travel_plans WHERE id = ? AND user_id = ?', [id, req.session.userId]);
      return res.json({ success: true });
    }
    const idx = mockPlans.findIndex(p => p.id === id && p.user_id === req.session.userId);
    if (idx !== -1) mockPlans.splice(idx, 1);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to delete plan' });
  }
});

// ─── Serve HTML pages ─────────────────────────────────────────────────────────
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public', 'login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public', 'register.html')));
app.get('/planner', (req, res) => res.sendFile(path.join(__dirname, 'public', 'planner.html')));

// ─── Start ────────────────────────────────────────────────────────────────────
initDB().then(() => {
  app.listen(PORT, () => {
    console.log(`🌍 Travel Planner running at http://localhost:${PORT}`);
  });
});
